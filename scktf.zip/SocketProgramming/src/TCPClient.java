

	import java.io.*; 
	import java.net.*; 
  public class TCPClient { 
	
	    public static void main(String argv[]) throws Exception 
	    { 
	        String sentence; 
	        String modifiedSentence; 
String msgin="";
String msgout="";
//BufferedReader inFromUser = 
//new BufferedReader(new InputStreamReader(System.in));
//msgin=inFromUser.readLine();
BufferedReader inFromUser = 
new BufferedReader(new InputStreamReader(System.in));
while (!(msgin.equals("Connect"))){
	
			msgin=inFromUser.readLine();

}	       
while(true){
	//172.20.10.5
	Socket clientSocket = new Socket("172.20.10.5", 6789); 

	        DataOutputStream outToServer = 
	          new DataOutputStream(clientSocket.getOutputStream()); 

	
	        BufferedReader inFromServer = 
	                new BufferedReader(new
	                InputStreamReader(clientSocket.getInputStream())); 

	              sentence = inFromUser.readLine(); 
            if( sentence !=null|| !(sentence .equals(""))){
            	outToServer.writeBytes(sentence+ '\n');
            	outToServer.flush();
            	
            }


	              modifiedSentence = inFromServer.readLine(); 
	           //   System.out.println(" SERVER: "); 
	              if(modifiedSentence !=null || !(modifiedSentence.equals("")))
	              {
	              System.out.println("FROM SERVER: " + modifiedSentence); 
	              }
	              if (sentence.equals("end")){
	                  clientSocket.close();
    	              break;
                 }
	             // clientSocket.close(); 
}	                         
	    }
	       
	    }
	


 
