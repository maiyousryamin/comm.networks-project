

	import java.io.*; 
import java.net.*; 

	public class TCPServer { 
		
	  public static void main(String argv[]) throws Exception 
	    { 
	      String clientSentence = null; 
	      String capitalizedSentence; 
String msgin="";
String msgout="";
boolean flag=true;

	   ServerSocket welcomeSocket = new ServerSocket(6789); 
	  
	      while(true) { 
	    	  
	  
	            Socket connectionSocket = welcomeSocket.accept(); 

	           BufferedReader inFromClient = 
	              new BufferedReader(new
	              InputStreamReader(connectionSocket.getInputStream())); 


	           DataOutputStream  outToClient = 
	             new DataOutputStream(connectionSocket.getOutputStream());
//	           if (inFromClient.equals("end") ){
//	        	   outToClient.writeBytes("end"+ '\n');
//	        	   flag=false;
//	        	 
	        	  
	          // }
	           if (flag==true){
	        	  
	           
	           if(inFromClient!=null){ 

	           clientSentence = inFromClient.readLine();
	           
	            if (clientSentence!=null || !(clientSentence.equals(""))  ){
	           System.out.println("c:"+ clientSentence);
	           }
	           
	           }
	          
	           BufferedReader inFromUser=new BufferedReader(new InputStreamReader(System.in));
	           
	           if(inFromUser != null){
	           msgin=inFromUser.readLine();
	           
	     //      if(outToClient !=null){
	        	   outToClient.writeBytes(msgin+ '\n'); 
	        	 //  System.out.println("buffer :"+msgin);
	        	   outToClient.flush();
	       //    }
	           }
	    //   capitalizedSentence = clientSentence.toUpperCase() + '\n'; 
	           if(clientSentence.equals("end")){
	        	   System.out.println("exit");
	        	 //  connectionSocket.close();
	        	   flag=false;
	        	   
	           }
	         
	          
	           }
	          
	        	  
	         
}
	      
	    
	    }
	}
